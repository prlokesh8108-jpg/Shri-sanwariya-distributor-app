package com.shrisanwariya.distributor

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.shrisanwariya.distributor.model.*
import com.shrisanwariya.distributor.ui.DistributorViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: DistributorViewModel = viewModel()
            val settings by vm.repository.settings.collectAsState()
            val brandColor = remember(settings.primaryColorHex) {
                runCatching { Color(android.graphics.Color.parseColor(settings.primaryColorHex)) }
                    .getOrDefault(Color(0xFF006C67))
            }
            val scheme = lightColorScheme(
                primary = brandColor,
                secondary = Color(0xFF1559A8),
                tertiary = Color(0xFF9A5B18),
                background = Color(0xFFF6FAF9),
                surface = Color.White
            )
            MaterialTheme(colorScheme = scheme) {
                ShriSanwariyaRootScreen(vm = vm, brandColor = brandColor)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShriSanwariyaRootScreen(vm: DistributorViewModel, brandColor: Color) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var editingProduct by remember { mutableStateOf<Product?>(null) }
    var showProductDialog by remember { mutableStateOf(false) }

    val settings by vm.repository.settings.collectAsState()
    val products by vm.repository.products.collectAsState()
    val companies by vm.repository.companies.collectAsState()
    val categories by vm.repository.categories.collectAsState()
    val schemes by vm.repository.schemes.collectAsState()
    val orders by vm.repository.orders.collectAsState()
    val cart by vm.cart.collectAsState()
    val isCloud by vm.repository.isCloudConnected.collectAsState()
    val syncStatus by vm.repository.syncStatusText.collectAsState()
    val toast by vm.toastMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(toast) {
        toast?.let {
            snackbarHostState.showSnackbar(it)
            vm.clearToast()
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri: Uri? -> uri?.let { vm.exportBackup(it) } }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let { vm.importBackup(it) } }

    val cartCount = cart.values.sum()

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            if (selectedTab == 0) {
                ExtendedFloatingActionButton(
                    onClick = { editingProduct = null; showProductDialog = true },
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text("Add Product") },
                    containerColor = brandColor,
                    contentColor = Color.White
                )
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Storefront, null) },
                    label = { Text("Catalog") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = {
                        BadgedBox(badge = { if (cartCount > 0) Badge { Text("$cartCount") } }) {
                            Icon(Icons.Default.ShoppingCart, null)
                        }
                    },
                    label = { Text("Order") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.PictureAsPdf, null) },
                    label = { Text("Invoices") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.AdminPanelSettings, null) },
                    label = { Text("Owner") }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (selectedTab) {
                0 -> CatalogTab(
                    settings = settings,
                    brandColor = brandColor,
                    products = products.filter { p ->
                        val comp = companies.find { it.id == p.companyId }
                        p.available && (comp == null || !comp.hidden)
                    },
                    companies = companies.filter { !it.hidden },
                    categories = categories,
                    schemes = schemes,
                    cart = cart,
                    isCloud = isCloud,
                    syncStatus = syncStatus,
                    vm = vm
                )
                1 -> CartCheckoutTab(vm = vm, brandColor = brandColor, onOrderPlaced = { selectedTab = 2 }, onBrowseCatalog = { selectedTab = 0 })
                2 -> OrdersPdfTab(
                    orders = orders,
                    brandColor = brandColor,
                    onDownloadPdf = { vm.downloadAndShareOrderPdf(it) },
                    onShareText = { vm.shareOrderTextSummary(it) },
                    onRepeatOrder = { vm.repeatOrderToCart(it); selectedTab = 1 },
                    onUpdateStatus = { id, st -> vm.repository.updateOrderStatus(id, st) }
                )
                3 -> OwnerStudioTab(
                    settings = settings,
                    brandColor = brandColor,
                    products = products,
                    companies = companies,
                    categories = categories,
                    schemes = schemes,
                    orders = orders,
                    isCloud = isCloud,
                    syncStatus = syncStatus,
                    vm = vm,
                    onAddProduct = { editingProduct = null; showProductDialog = true },
                    onEditProduct = { editingProduct = it; showProductDialog = true },
                    onExport = { exportLauncher.launch("ShriSanwariya_Backup_v4.zip") },
                    onImport = { importLauncher.launch(arrayOf("application/zip", "application/json", "*/*")) }
                )
            }
        }
    }

    if (showProductDialog) {
        ProductEditorDialog(
            existing = editingProduct,
            companies = companies,
            categories = categories,
            schemes = schemes,
            vm = vm,
            onDismiss = { showProductDialog = false }
        )
    }
}

@Composable
fun CatalogTab(
    settings: StoreSettings,
    brandColor: Color,
    products: List<Product>,
    companies: List<Company>,
    categories: List<Category>,
    schemes: List<Scheme>,
    cart: Map<String, Int>,
    isCloud: Boolean,
    syncStatus: String,
    vm: DistributorViewModel
) {
    var selectedCompanyId by remember { mutableStateOf<String?>(null) }
    var selectedCategoryId by remember { mutableStateOf<String?>(null) }
    var search by remember { mutableStateOf("") }
    val schemeMap = remember(schemes) { schemes.associateBy { it.id } }

    val filtered = products.filter { p ->
        (selectedCompanyId == null || p.companyId == selectedCompanyId) &&
            (selectedCategoryId == null || p.categoryId == selectedCategoryId) &&
            (search.isBlank() || p.name.contains(search, true) || p.companyName.contains(search, true) || p.categoryName.contains(search, true))
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (settings.announcement.isNotBlank()) {
            item {
                Surface(color = Color(0xFFFFF8E1), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "📢 ${settings.announcement}",
                        color = Color(0xFF9A5B18),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Brush.linearGradient(listOf(brandColor, Color(0xFF1559A8))))
                    .padding(18.dp)
            ) {
                Canvas(modifier = Modifier.matchParentSize()) {
                    drawCircle(Color.White.copy(alpha = 0.08f), radius = 90f, center = Offset(size.width - 30f, 20f))
                    drawCircle(Color(0xFFFFD166).copy(alpha = 0.14f), radius = 55f, center = Offset(size.width - 90f, size.height))
                }
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = if (isCloud) Color(0xFF10B981) else Color(0xFFF59E0B),
                            shape = RoundedCornerShape(50)
                        ) {
                            Text(
                                text = if (isCloud) "● LIVE SYNC" else "● LOCAL MODE",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(syncStatus, color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(settings.distributorName, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                    Text(settings.tagline, color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
                }
            }
        }

        item {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                placeholder = { Text("Search products or brands...") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = selectedCompanyId == null,
                        onClick = { selectedCompanyId = null },
                        label = { Text("All Brands (${products.size})") }
                    )
                }
                items(companies) { c ->
                    FilterChip(
                        selected = selectedCompanyId == c.id,
                        onClick = { selectedCompanyId = if (selectedCompanyId == c.id) null else c.id },
                        label = { Text(c.name) }
                    )
                }
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = selectedCategoryId == null,
                        onClick = { selectedCategoryId = null },
                        label = { Text("All Categories", fontSize = 11.sp) }
                    )
                }
                items(categories) { cat ->
                    FilterChip(
                        selected = selectedCategoryId == cat.id,
                        onClick = { selectedCategoryId = if (selectedCategoryId == cat.id) null else cat.id },
                        label = { Text(cat.name, fontSize = 11.sp) }
                    )
                }
            }
        }

        items(filtered, key = { it.id }) { product ->
            val scheme = product.schemeId?.let { schemeMap[it] }
            val qtyInCart = cart[product.id] ?: 0
            val imgFile = vm.backupManager.resolveLocalImageFile(product.imageRelativePath)

            ElevatedCard(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(74.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(brandColor.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (imgFile != null || !product.imageUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = imgFile ?: product.imageUrl,
                                contentDescription = product.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(iconForKey(product.iconKey), contentDescription = null, tint = brandColor, modifier = Modifier.size(34.dp))
                        }
                    }

                    Spacer(Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(product.companyName, color = Color(0xFF1559A8), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        Text(product.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 2)
                        Text("Pack: ${product.packSize}", color = Color.Gray, fontSize = 12.sp)
                        Spacer(Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(formatRs(product.rate), color = brandColor, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                            Spacer(Modifier.width(8.dp))
                            Text("MRP " + formatRs(product.mrp), color = Color.Gray, fontSize = 12.sp, textDecoration = TextDecoration.LineThrough)
                        }
                        if (scheme != null && scheme.active) {
                            Spacer(Modifier.height(4.dp))
                            Surface(color = Color(0xFFFFF3E0), shape = RoundedCornerShape(6.dp)) {
                                Text(
                                    text = "★ ${scheme.shortBadge()}",
                                    color = Color(0xFF9A5B18),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (qtyInCart == 0) {
                            Button(
                                onClick = { vm.addToCart(product.id, 1) },
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) { Text("+ Add", fontSize = 12.sp) }
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { vm.addToCart(product.id, -1) }, modifier = Modifier.size(30.dp)) {
                                    Icon(Icons.Default.RemoveCircleOutline, null, tint = Color(0xFFAE3256))
                                }
                                Text("$qtyInCart", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
                                IconButton(onClick = { vm.addToCart(product.id, 1) }, modifier = Modifier.size(30.dp)) {
                                    Icon(Icons.Default.AddCircleOutline, null, tint = brandColor)
                                }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Surface(
                                    color = brandColor.copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.clickable { vm.addToCart(product.id, 5) }
                                ) {
                                    Text("+5", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = brandColor, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                                Surface(
                                    color = brandColor.copy(alpha = 0.12f),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.clickable { vm.addToCart(product.id, 10) }
                                ) {
                                    Text("+10", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = brandColor, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(72.dp)) }
    }
}

@Composable
fun CartCheckoutTab(
    vm: DistributorViewModel,
    brandColor: Color,
    onOrderPlaced: () -> Unit,
    onBrowseCatalog: () -> Unit
) {
    val cart by vm.cart.collectAsState()
    val products by vm.repository.products.collectAsState()
    val schemes by vm.repository.schemes.collectAsState()
    val lines = remember(cart, products, schemes) { vm.getCartLineItems() }
    var partyName by remember { mutableStateOf("") }
    var partyMobile by remember { mutableStateOf("") }
    var partyAddress by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Party Order & PDF Checkout", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = brandColor) }
        if (lines.isEmpty()) {
            item {
                ElevatedCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = Color.White)
                ) {
                    Column(
                        Modifier.padding(24.dp).fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.ShoppingBag, null, tint = brandColor, modifier = Modifier.size(52.dp))
                        Spacer(Modifier.height(10.dp))
                        Text("No products in cart yet", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Add items from the Catalog first to calculate schemes and generate a Party Order PDF.",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = onBrowseCatalog, shape = RoundedCornerShape(12.dp)) {
                            Icon(Icons.Default.Storefront, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Go to Catalog & Add Products")
                        }
                    }
                }
            }
        } else {
            items(lines) { line ->
                ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(line.itemName, fontWeight = FontWeight.Bold)
                            Text(formatRs(line.netAmount), fontWeight = FontWeight.ExtraBold, color = brandColor)
                        }
                        Text("MRP ${formatRs(line.mrp)}  |  Rate ${formatRs(line.rate)}  |  Qty: ${line.paidQty} (+${line.freeQty} FREE)", fontSize = 12.sp, color = Color.DarkGray)
                        Text("Scheme: ${line.schemeLabel}  •  Savings: ${formatRs(line.discountAmount)}", fontSize = 11.sp, color = Color(0xFF9A5B18), fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            item {
                val recentParties = remember(vm.repository.orders.collectAsState().value) {
                    vm.repository.orders.value
                        .filter { it.partyName.isNotBlank() }
                        .distinctBy { it.partyName.trim().lowercase() }
                        .take(6)
                }
                if (recentParties.isNotEmpty()) {
                    Text("Quick-Fill Saved Party (1 Tap)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = brandColor)
                    Spacer(Modifier.height(4.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(recentParties) { past ->
                            AssistChip(
                                onClick = {
                                    partyName = past.partyName
                                    partyMobile = past.partyMobile
                                    partyAddress = past.partyAddress
                                },
                                label = { Text(past.partyName, fontSize = 11.sp) },
                                leadingIcon = { Icon(Icons.Default.Person, null, modifier = Modifier.size(15.dp)) }
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                OutlinedTextField(partyName, { partyName = it }, label = { Text("Party / Shop Name *") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(partyMobile, { partyMobile = it }, label = { Text("10-digit Mobile") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(partyAddress, { partyAddress = it }, label = { Text("Party Address / Route") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(notes, { notes = it }, label = { Text("Order Notes") }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(14.dp))
                val grand = lines.sumOf { it.netAmount }
                val saved = lines.sumOf { it.discountAmount }
                Button(
                    onClick = {
                        val created = vm.placeOrderAndGeneratePdf(partyName, partyMobile, partyAddress, notes)
                        if (created != null) onOrderPlaced()
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.PictureAsPdf, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Place Order & Generate PDF (${formatRs(grand)} | Save ${formatRs(saved)})", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun OrdersPdfTab(
    orders: List<PartyOrder>,
    brandColor: Color,
    onDownloadPdf: (PartyOrder) -> Unit,
    onShareText: (PartyOrder) -> Unit,
    onRepeatOrder: (PartyOrder) -> Unit,
    onUpdateStatus: (String, String) -> Unit
) {
    val fmt = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Party Orders & PDF Invoices", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = brandColor) }
        if (orders.isEmpty()) {
            item { Text("No orders placed yet. Place an order to view & download its PDF invoice.", color = Color.Gray) }
        }
        items(orders, key = { it.id }) { order ->
            ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(order.partyName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(formatRs(order.grandTotal), fontWeight = FontWeight.ExtraBold, color = brandColor)
                    }
                    Text("${order.id} • ${fmt.format(Date(order.createdAt))} • Status: ${order.status}", fontSize = 11.sp, color = Color.Gray)
                    Text("${order.items.size} items • ${order.totalFreeUnits} FREE units • Discount ${formatRs(order.totalDiscount)}", fontSize = 12.sp, color = Color(0xFF9A5B18))
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Accepted", "Packed", "Delivered").forEach { st ->
                            FilterChip(
                                selected = order.status == st,
                                onClick = { onUpdateStatus(order.id, st) },
                                label = { Text(st, fontSize = 11.sp) }
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { onDownloadPdf(order) },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Download, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Download & Share PDF Invoice")
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { onShareText(order) },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("WhatsApp Text", fontSize = 12.sp)
                        }
                        OutlinedButton(
                            onClick = { onRepeatOrder(order) },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Replay, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Repeat Order", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OwnerStudioTab(
    settings: StoreSettings,
    brandColor: Color,
    products: List<Product>,
    companies: List<Company>,
    categories: List<Category>,
    schemes: List<Scheme>,
    orders: List<PartyOrder>,
    isCloud: Boolean,
    syncStatus: String,
    vm: DistributorViewModel,
    onAddProduct: () -> Unit,
    onEditProduct: (Product) -> Unit,
    onExport: () -> Unit,
    onImport: () -> Unit
) {
    var ownerSubTab by remember { mutableIntStateOf(0) }
    var distName by remember(settings.distributorName) { mutableStateOf(settings.distributorName) }
    var tagline by remember(settings.tagline) { mutableStateOf(settings.tagline) }
    var announcement by remember(settings.announcement) { mutableStateOf(settings.announcement) }
    var colorHex by remember(settings.primaryColorHex) { mutableStateOf(settings.primaryColorHex) }

    var newCompanyName by remember { mutableStateOf("") }
    var newCategoryName by remember { mutableStateOf("") }
    var newSchemeTitle by remember { mutableStateOf("") }
    var newSchemeMin by remember { mutableStateOf("10") }
    var newSchemeFree by remember { mutableStateOf("2") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Owner Studio (Full Control)", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = brandColor)
            Text("Edit store appearance, products, companies, categories, schemes, and backups.", fontSize = 12.sp, color = Color.Gray)
            Spacer(Modifier.height(8.dp))
            val totalRevenue = orders.sumOf { it.grandTotal }
            val totalFree = orders.sumOf { it.totalFreeUnits }
            ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(14.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Total Orders", fontSize = 11.sp, color = Color.Gray)
                        Text("${orders.size}", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = brandColor)
                    }
                    Column {
                        Text("Total Billing", fontSize = 11.sp, color = Color.Gray)
                        Text(formatRs(totalRevenue), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = brandColor)
                    }
                    Column {
                        Text("Free Units", fontSize = 11.sp, color = Color.Gray)
                        Text("$totalFree", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = Color(0xFF9A5B18))
                    }
                }
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Appearance", "Products (${products.size})", "Brands & Cats", "Schemes", "Sync & Backup").forEachIndexed { idx, label ->
                    item {
                        FilterChip(
                            selected = ownerSubTab == idx,
                            onClick = { ownerSubTab = idx },
                            label = { Text(label) }
                        )
                    }
                }
            }
        }

        when (ownerSubTab) {
            0 -> {
                item {
                    ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Appearance & Store Settings", fontWeight = FontWeight.Bold)
                            OutlinedTextField(distName, { distName = it }, label = { Text("Distributor / Shop Name") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(tagline, { tagline = it }, label = { Text("Tagline") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(announcement, { announcement = it }, label = { Text("Announcement (leave blank to hide)") }, modifier = Modifier.fillMaxWidth())
                            Text("Brand Colour", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                listOf("#006C67", "#1559A8", "#5B3CC4", "#9A5B18", "#AE3256").forEach { hex ->
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                            .background(Color(android.graphics.Color.parseColor(hex)))
                                            .clickable { colorHex = hex },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (colorHex.equals(hex, true)) {
                                            Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            }
                            Button(
                                onClick = {
                                    vm.repository.updateSettings(
                                        settings.copy(
                                            distributorName = distName.ifBlank { "Shri Sanwariya Distributor" },
                                            tagline = tagline,
                                            announcement = announcement,
                                            primaryColorHex = colorHex
                                        )
                                    )
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Save & Sync Appearance") }
                        }
                    }
                }
            }
            1 -> {
                item {
                    Button(onClick = onAddProduct, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Add, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Add New Product")
                    }
                }
                items(products, key = { it.id }) { p ->
                    ElevatedCard(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.Bold)
                                Text("${p.companyName} • ${p.packSize} • Rate ${formatRs(p.rate)} / MRP ${formatRs(p.mrp)}", fontSize = 12.sp, color = Color.Gray)
                                Text(if (p.available) "Visible in Catalog" else "Hidden from Catalog", fontSize = 11.sp, color = if (p.available) Color(0xFF059669) else Color(0xFFAE3256))
                            }
                            IconButton(onClick = { onEditProduct(p) }) { Icon(Icons.Default.Edit, null, tint = Color(0xFF1559A8)) }
                            IconButton(onClick = { vm.repository.upsertProduct(p.copy(available = !p.available)) }) {
                                Icon(if (p.available) Icons.Default.Visibility else Icons.Default.VisibilityOff, null)
                            }
                            IconButton(onClick = { vm.repository.deleteProduct(p.id) }) { Icon(Icons.Default.Delete, null, tint = Color(0xFFAE3256)) }
                        }
                    }
                }
            }
            2 -> {
                item {
                    ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Companies / Brands", fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(newCompanyName, { newCompanyName = it }, label = { Text("New Company") }, modifier = Modifier.weight(1f), singleLine = true)
                                Button(onClick = {
                                    if (newCompanyName.isNotBlank()) {
                                        vm.repository.upsertCompany(Company(name = newCompanyName.trim()))
                                        newCompanyName = ""
                                    }
                                }) { Text("Add") }
                            }
                            companies.forEach { c ->
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text(c.name, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                    TextButton(onClick = { vm.repository.upsertCompany(c.copy(hidden = !c.hidden)) }) {
                                        Text(if (c.hidden) "Hidden" else "Visible")
                                    }
                                    IconButton(onClick = { vm.repository.deleteCompany(c.id) }) {
                                        Icon(Icons.Default.Delete, null, tint = Color(0xFFAE3256))
                                    }
                                }
                            }
                        }
                    }
                }
                item {
                    ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Categories", fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(newCategoryName, { newCategoryName = it }, label = { Text("New Category") }, modifier = Modifier.weight(1f), singleLine = true)
                                Button(onClick = {
                                    if (newCategoryName.isNotBlank()) {
                                        vm.repository.upsertCategory(Category(name = newCategoryName.trim()))
                                        newCategoryName = ""
                                    }
                                }) { Text("Add") }
                            }
                            categories.forEach { cat ->
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text(cat.name, modifier = Modifier.weight(1f))
                                    IconButton(onClick = { vm.repository.deleteCategory(cat.id) }) {
                                        Icon(Icons.Default.Delete, null, tint = Color(0xFFAE3256))
                                    }
                                }
                            }
                        }
                    }
                }
            }
            3 -> {
                item {
                    ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Create Free-Unit Scheme", fontWeight = FontWeight.Bold)
                            OutlinedTextField(newSchemeTitle, { newSchemeTitle = it }, label = { Text("Scheme Title (e.g. Buy 12 + 2 FREE)") }, modifier = Modifier.fillMaxWidth())
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(newSchemeMin, { newSchemeMin = it }, label = { Text("Min Paid") }, modifier = Modifier.weight(1f))
                                OutlinedTextField(newSchemeFree, { newSchemeFree = it }, label = { Text("Free Units") }, modifier = Modifier.weight(1f))
                            }
                            Button(onClick = {
                                if (newSchemeTitle.isNotBlank()) {
                                    vm.repository.upsertScheme(
                                        Scheme(
                                            title = newSchemeTitle.trim(),
                                            type = SchemeType.FREE_UNITS,
                                            minPaidUnits = newSchemeMin.toIntOrNull() ?: 10,
                                            freeUnits = newSchemeFree.toIntOrNull() ?: 1
                                        )
                                    )
                                    newSchemeTitle = ""
                                }
                            }, modifier = Modifier.fillMaxWidth()) { Text("Save Scheme") }
                        }
                    }
                }
                items(schemes, key = { it.id }) { s ->
                    ElevatedCard(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(s.title, fontWeight = FontWeight.Bold)
                                Text(s.shortBadge(), fontSize = 12.sp, color = Color(0xFF9A5B18))
                            }
                            Switch(checked = s.active, onCheckedChange = { vm.repository.upsertScheme(s.copy(active = it)) })
                            IconButton(onClick = { vm.repository.deleteScheme(s.id) }) { Icon(Icons.Default.Delete, null, tint = Color(0xFFAE3256)) }
                        }
                    }
                }
            }
            4 -> {
                item {
                    ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Cloud Sync Status", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text(syncStatus, color = if (isCloud) Color(0xFF059669) else Color(0xFFD97706), fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(6.dp))
                            Text("Products: ${products.size}  •  Orders: ${orders.size}", fontSize = 13.sp, color = Color.Gray)
                        }
                    }
                }
                item {
                    ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Cross-Device Backup & Restore (v4 Fixed)", fontWeight = FontWeight.Bold)
                            Text("Exports a checksum-verified .zip with UTF-8 data and portable product photos that imports cleanly on any phone or PC.", fontSize = 12.sp, color = Color.Gray)
                            Button(onClick = onExport, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.UploadFile, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Export Valid Backup (.zip)")
                            }
                            OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.DownloadForOffline, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Import Backup (.zip or .json)")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun iconForKey(key: String) = when (key) {
    "cosmetic" -> Icons.Default.FaceRetouchingNatural
    "bottle" -> Icons.Default.LocalDrink
    "soap" -> Icons.Default.CleanHands
    "baby" -> Icons.Default.ChildCare
    "home" -> Icons.Default.Home
    else -> Icons.Default.Inventory2
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductEditorDialog(
    existing: Product?,
    companies: List<Company>,
    categories: List<Category>,
    schemes: List<Scheme>,
    vm: DistributorViewModel,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var packSize by remember { mutableStateOf(existing?.packSize ?: "1 kg") }
    var mrp by remember { mutableStateOf(existing?.mrp?.toString() ?: "") }
    var rate by remember { mutableStateOf(existing?.rate?.toString() ?: "") }
    var selectedCompany by remember { mutableStateOf(companies.find { it.id == existing?.companyId } ?: companies.firstOrNull()) }
    var selectedCategory by remember { mutableStateOf(categories.find { it.id == existing?.categoryId } ?: categories.firstOrNull()) }
    var selectedScheme by remember { mutableStateOf(schemes.find { it.id == existing?.schemeId }) }
    var selectedIconKey by remember { mutableStateOf(existing?.iconKey ?: "box") }
    var pickedPhotoUri by remember { mutableStateOf<Uri?>(null) }

    var companyExpanded by remember { mutableStateOf(false) }
    var categoryExpanded by remember { mutableStateOf(false) }
    var schemeExpanded by remember { mutableStateOf(false) }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> pickedPhotoUri = uri }

    val iconOptions = listOf(
        "box" to "General",
        "cosmetic" to "Cosmetic",
        "bottle" to "Liquid",
        "soap" to "Hygiene",
        "baby" to "Baby",
        "home" to "Home"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Add New Product" else "Edit Product", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(name, { name = it }, label = { Text("Product Name *") }, singleLine = true, modifier = Modifier.fillMaxWidth())

                // Company / Brand Dropdown
                ExposedDropdownMenuBox(
                    expanded = companyExpanded,
                    onExpandedChange = { companyExpanded = !companyExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedCompany?.name ?: "Select Company",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Company / Brand") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = companyExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = companyExpanded, onDismissRequest = { companyExpanded = false }) {
                        companies.forEach { c ->
                            DropdownMenuItem(
                                text = { Text(c.name) },
                                onClick = { selectedCompany = c; companyExpanded = false }
                            )
                        }
                    }
                }

                // Category Dropdown (General, Cosmetic, etc.)
                ExposedDropdownMenuBox(
                    expanded = categoryExpanded,
                    onExpandedChange = { categoryExpanded = !categoryExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedCategory?.name ?: "Select Category",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Category (General / Cosmetic / etc.)") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = categoryExpanded, onDismissRequest = { categoryExpanded = false }) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat.name) },
                                onClick = { selectedCategory = cat; categoryExpanded = false }
                            )
                        }
                    }
                }

                OutlinedTextField(packSize, { packSize = it }, label = { Text("Pack Size (e.g. 250 ml, 1 kg)") }, singleLine = true, modifier = Modifier.fillMaxWidth())

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(mrp, { mrp = it }, label = { Text("MRP ₹ *") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(rate, { rate = it }, label = { Text("Rate ₹ *") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                val mrpNum = mrp.toDoubleOrNull() ?: 0.0
                val rateNum = rate.toDoubleOrNull() ?: 0.0
                if (mrpNum > 0 && rateNum > 0) {
                    val marginPct = ((mrpNum - rateNum) / mrpNum) * 100.0
                    Text(
                        text = "Margin: ${String.format(java.util.Locale.US, "%.1f", marginPct)}% (Profit ${formatRs(mrpNum - rateNum)} / unit on MRP)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (marginPct >= 0) Color(0xFF059669) else Color(0xFFAE3256)
                    )
                }

                // Scheme Dropdown
                ExposedDropdownMenuBox(
                    expanded = schemeExpanded,
                    onExpandedChange = { schemeExpanded = !schemeExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedScheme?.let { "${it.title} (${it.shortBadge()})" } ?: "No Scheme",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Attach Scheme") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = schemeExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = schemeExpanded, onDismissRequest = { schemeExpanded = false }) {
                        DropdownMenuItem(
                            text = { Text("No Scheme") },
                            onClick = { selectedScheme = null; schemeExpanded = false }
                        )
                        schemes.forEach { s ->
                            DropdownMenuItem(
                                text = { Text("${s.title} (${s.shortBadge()})") },
                                onClick = { selectedScheme = s; schemeExpanded = false }
                            )
                        }
                    }
                }

                // Built-in Icon Picker (optional if no photo)
                Text("Product Icon (or upload photo below)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(iconOptions) { (key, label) ->
                        FilterChip(
                            selected = selectedIconKey == key,
                            onClick = { selectedIconKey = key },
                            leadingIcon = { Icon(iconForKey(key), null, modifier = Modifier.size(16.dp)) },
                            label = { Text(label, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedButton(onClick = { photoPicker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Image, null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (pickedPhotoUri != null) "New Photo Selected ✓" else "Pick / Change Product Photo")
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val mrpVal = mrp.toDoubleOrNull() ?: 0.0
                val rateVal = rate.toDoubleOrNull() ?: mrpVal
                if (name.isNotBlank() && mrpVal > 0) {
                    val prodId = existing?.id ?: "prod_${System.currentTimeMillis()}"
                    val savedImg = pickedPhotoUri?.let { vm.backupManager.saveProductImageFromUri(prodId, it) } ?: existing?.imageRelativePath
                    val comp = selectedCompany ?: Company("comp_gen", "General")
                    val cat = selectedCategory ?: Category("cat_gen", "General")
                    vm.repository.upsertProduct(
                        Product(
                            id = prodId,
                            name = name.trim(),
                            companyId = comp.id,
                            companyName = comp.name,
                            categoryId = cat.id,
                            categoryName = cat.name,
                            packSize = packSize.ifBlank { "1 unit" },
                            mrp = mrpVal,
                            rate = rateVal,
                            schemeId = selectedScheme?.id,
                            imageRelativePath = savedImg,
                            iconKey = selectedIconKey,
                            available = existing?.available ?: true
                        )
                    )
                    onDismiss()
                }
            }) { Text("Save & Sync") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
