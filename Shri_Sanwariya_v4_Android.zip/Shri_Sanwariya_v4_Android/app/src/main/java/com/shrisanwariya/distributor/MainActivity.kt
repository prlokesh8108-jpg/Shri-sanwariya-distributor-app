package com.shrisanwariya.distributor

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.shrisanwariya.distributor.model.*
import com.shrisanwariya.distributor.ui.DistributorViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: DistributorViewModel = viewModel()
            val settings by vm.repository.settings.collectAsState()
            val brandColor = remember(settings.primaryColorHex) {
                runCatching { Color(android.graphics.Color.parseColor(settings.primaryColorHex)) }
                    .getOrDefault(Color(0xFF006C67))
            }
            val scheme = lightColorScheme(
                primary = brandColor,
                secondary = Color(0xFF1559A8),
                tertiary = Color(0xFF9A5B18),
                background = Color(0xFFF2F6F5),
                surface = Color.White
            )
            MaterialTheme(colorScheme = scheme) {
                ShriSanwariyaRootScreen(vm = vm, brandColor = brandColor)
            }
        }
    }
}

@Composable
fun ShriSanwariyaRootScreen(vm: DistributorViewModel, brandColor: Color) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var ownerUnlocked by remember { mutableStateOf(false) }
    var editingProduct by remember { mutableStateOf<Product?>(null) }
    var showProductDialog by remember { mutableStateOf(false) }

    val settings by vm.repository.settings.collectAsState()
    val products by vm.repository.products.collectAsState()
    val companies by vm.repository.companies.collectAsState()
    val categories by vm.repository.categories.collectAsState()
    val schemes by vm.repository.schemes.collectAsState()
    val orders by vm.repository.orders.collectAsState()
    val cart by vm.cart.collectAsState()
    val isCloud by vm.repository.isCloudConnected.collectAsState()
    val syncStatus by vm.repository.syncStatusText.collectAsState()
    val toast by vm.toastMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(toast) {
        toast?.let {
            snackbarHostState.showSnackbar(it)
            vm.clearToast()
        }
    }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri: Uri? -> uri?.let { vm.exportBackup(it) } }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? -> uri?.let { vm.importBackup(it) } }

    val cartCount = cart.values.sum()

    Scaffold(
        containerColor = Color(0xFFF2F6F5),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            // Unique Floating Dark-Ink Pill Navigation Dock
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(28.dp),
                    color = Color(0xFF0F172A),
                    shadowElevation = 12.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val navItems = listOf(
                            Triple(0, "Reels", Icons.Default.AutoAwesomeMotion),
                            Triple(1, "Order", Icons.Default.ShoppingBag),
                            Triple(2, "Invoices", Icons.Default.ReceiptLong),
                            Triple(3, "Owner", if (ownerUnlocked) Icons.Default.VerifiedUser else Icons.Default.Lock)
                        )
                        navItems.forEach { (idx, label, icon) ->
                            val active = selectedTab == idx
                            Surface(
                                shape = RoundedCornerShape(22.dp),
                                color = if (active) brandColor else Color.Transparent,
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(22.dp))
                                    .clickable { selectedTab = idx }
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box {
                                        Icon(
                                            icon,
                                            contentDescription = label,
                                            tint = if (active) Color.White else Color(0xFF94A3B8),
                                            modifier = Modifier.size(19.dp)
                                        )
                                        if (idx == 1 && cartCount > 0) {
                                            Box(
                                                modifier = Modifier
                                                    .align(Alignment.TopEnd)
                                                    .offset(x = 6.dp, y = (-4).dp)
                                                    .size(16.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(0xFFF59E0B)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("$cartCount", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                    if (active) {
                                        Spacer(Modifier.width(5.dp))
                                        Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (selectedTab) {
                0 -> ReelsCatalogTab(
                    settings = settings,
                    brandColor = brandColor,
                    products = products.filter { p ->
                        val comp = companies.find { it.id == p.companyId }
                        p.available && (comp == null || !comp.hidden)
                    },
                    companies = companies.filter { !it.hidden },
                    categories = categories,
                    schemes = schemes,
                    cart = cart,
                    isCloud = isCloud,
                    syncStatus = syncStatus,
                    vm = vm
                )
                1 -> CartCheckoutTab(
                    vm = vm,
                    brandColor = brandColor,
                    onOrderPlaced = { selectedTab = 2 },
                    onBrowseCatalog = { selectedTab = 0 }
                )
                2 -> OrdersPdfTab(
                    orders = orders,
                    brandColor = brandColor,
                    onDownloadPdf = { vm.downloadAndShareOrderPdf(it) },
                    onShareText = { vm.shareOrderTextSummary(it) },
                    onRepeatOrder = { vm.repeatOrderToCart(it); selectedTab = 1 },
                    onUpdateStatus = { id, st -> vm.repository.updateOrderStatus(id, st) }
                )
                3 -> {
                    if (!ownerUnlocked) {
                        OwnerPinVaultScreen(
                            expectedPin = settings.ownerPin.ifBlank { "8107" },
                            brandColor = brandColor,
                            onUnlocked = { ownerUnlocked = true }
                        )
                    } else {
                        OwnerStudioTab(
                            settings = settings,
                            brandColor = brandColor,
                            products = products,
                            companies = companies,
                            categories = categories,
                            schemes = schemes,
                            orders = orders,
                            isCloud = isCloud,
                            syncStatus = syncStatus,
                            vm = vm,
                            onLockOwner = { ownerUnlocked = false },
                            onAddProduct = { editingProduct = null; showProductDialog = true },
                            onEditProduct = { editingProduct = it; showProductDialog = true },
                            onExport = { exportLauncher.launch("ShriSanwariya_Backup_v4.zip") },
                            onImport = { importLauncher.launch(arrayOf("application/zip", "application/json", "*/*")) }
                        )
                    }
                }
            }
        }
    }

    if (showProductDialog) {
        ProductEditorDialog(
            existing = editingProduct,
            companies = companies,
            categories = categories,
            vm = vm,
            onDismiss = { showProductDialog = false }
        )
    }
}

@Composable
fun OwnerPinVaultScreen(
    expectedPin: String,
    brandColor: Color,
    onUnlocked: () -> Unit
) {
    var pinInput by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    fun pressDigit(d: String) {
        if (pinInput.length < expectedPin.length.coerceAtLeast(4)) {
            val next = pinInput + d
            pinInput = next
            errorMsg = null
            if (next.length == expectedPin.length) {
                if (next == expectedPin) {
                    onUnlocked()
                } else {
                    errorMsg = "Wrong PIN. Try again."
                    pinInput = ""
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF0F172A), brandColor)))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier.size(68.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.VerifiedUser, null, tint = Color.White, modifier = Modifier.size(34.dp))
        }
        Spacer(Modifier.height(14.dp))
        Text("Owner Vault", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
        Text("Enter synced PIN to unlock management tools", fontSize = 12.sp, color = Color.White.copy(alpha = 0.75f))
        Spacer(Modifier.height(22.dp))

        // PIN Dots Indicator
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            repeat(expectedPin.length.coerceAtLeast(4)) { idx ->
                val filled = idx < pinInput.length
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(if (filled) Color(0xFF10B981) else Color.White.copy(alpha = 0.25f))
                )
            }
        }

        if (errorMsg != null) {
            Spacer(Modifier.height(10.dp))
            Text(errorMsg!!, color = Color(0xFFFCA5A5), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(24.dp))

        // Tactile Numeric Keypad
        val rows = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("CLR", "0", "DEL")
        )
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            rows.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    row.forEach { key ->
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.14f),
                            modifier = Modifier
                                .size(70.dp)
                                .clip(CircleShape)
                                .clickable {
                                    when (key) {
                                        "CLR" -> { pinInput = ""; errorMsg = null }
                                        "DEL" -> if (pinInput.isNotEmpty()) pinInput = pinInput.dropLast(1)
                                        else -> pressDigit(key)
                                    }
                                }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                if (key == "DEL") {
                                    Icon(Icons.AutoMirrored.Filled.Backspace, null, tint = Color.White)
                                } else {
                                    Text(
                                        key,
                                        color = Color.White,
                                        fontSize = if (key == "CLR") 13.sp else 22.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ReelsCatalogTab(
    settings: StoreSettings,
    brandColor: Color,
    products: List<Product>,
    companies: List<Company>,
    categories: List<Category>,
    schemes: List<Scheme>,
    cart: Map<String, Int>,
    isCloud: Boolean,
    syncStatus: String,
    vm: DistributorViewModel
) {
    var selectedCompanyId by remember { mutableStateOf<String?>(null) }
    var selectedCategoryId by remember { mutableStateOf<String?>(null) }
    var search by remember { mutableStateOf("") }
    var showFilters by remember { mutableStateOf(false) }
    val schemeMap = remember(schemes) { schemes.associateBy { it.id } }

    val filtered = products.filter { p ->
        (selectedCompanyId == null || p.companyId == selectedCompanyId) &&
            (selectedCategoryId == null || p.categoryId == selectedCategoryId) &&
            (search.isBlank() || p.name.contains(search, true) || p.companyName.contains(search, true) || p.categoryName.contains(search, true))
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Sleek Branded Top Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.horizontalGradient(listOf(Color(0xFF0F172A), brandColor)))
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(settings.distributorName, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier.size(8.dp).clip(CircleShape)
                                    .background(if (isCloud) Color(0xFF34D399) else Color(0xFFFBBF24))
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(syncStatus, fontSize = 11.sp, color = Color.White.copy(alpha = 0.85f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Surface(
                        shape = CircleShape,
                        color = Color.White.copy(alpha = 0.16f),
                        modifier = Modifier.size(38.dp).clip(CircleShape).clickable { showFilters = !showFilters }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(if (showFilters) Icons.Default.Close else Icons.Default.Tune, contentDescription = "Filter", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    }
                }

                if (settings.announcement.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Surface(color = Color.White.copy(alpha = 0.14f), shape = RoundedCornerShape(8.dp)) {
                        Text(
                            "📢 ${settings.announcement}",
                            fontSize = 11.sp,
                            color = Color(0xFFFDE68A),
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                if (showFilters) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = search,
                        onValueChange = { search = it },
                        placeholder = { Text("Search product, brand, category...", color = Color.Gray) },
                        leadingIcon = { Icon(Icons.Default.Search, null, tint = brandColor) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        item {
                            FilterChip(selected = selectedCompanyId == null, onClick = { selectedCompanyId = null }, label = { Text("All Brands", fontSize = 11.sp) })
                        }
                        items(companies) { c ->
                            FilterChip(selected = selectedCompanyId == c.id, onClick = { selectedCompanyId = if (selectedCompanyId == c.id) null else c.id }, label = { Text(c.name, fontSize = 11.sp) })
                        }
                    }
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        item {
                            FilterChip(selected = selectedCategoryId == null, onClick = { selectedCategoryId = null }, label = { Text("All Categories", fontSize = 11.sp) })
                        }
                        items(categories) { cat ->
                            FilterChip(selected = selectedCategoryId == cat.id, onClick = { selectedCategoryId = if (selectedCategoryId == cat.id) null else cat.id }, label = { Text(cat.name, fontSize = 11.sp) })
                        }
                    }
                }
            }
        }

        // Full-Screen Reels Showcase Pager
        if (filtered.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
                    Icon(Icons.Default.Inventory2, null, tint = brandColor, modifier = Modifier.size(56.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("No products match your filter", fontWeight = FontWeight.Bold)
                }
            }
        } else {
            val pagerState = rememberPagerState(pageCount = { filtered.size })
            VerticalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 10.dp),
                pageSpacing = 14.dp
            ) { page ->
                val product = filtered[page]
                val qtyInCart = cart[product.id] ?: 0
                val offerText = product.offerBadge(schemeMap)
                val imgFile = vm.backupManager.resolveLocalImageFile(product.imageRelativePath)
                val marginPct = if (product.mrp > 0) (((product.mrp - product.rate) / product.mrp) * 100.0) else 0.0

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .shadow(10.dp, RoundedCornerShape(28.dp))
                        .clip(RoundedCornerShape(28.dp))
                        .background(Color(0xFF0F172A))
                ) {
                    // 1. Full-bleed Photo or Artistic Vector Stage
                    if (imgFile != null || !product.imageUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = imgFile ?: product.imageUrl,
                            contentDescription = product.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        // Subtle bottom dark scrim for readability
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color.Black.copy(alpha = 0.25f), Color.Transparent, Color.Black.copy(alpha = 0.85f))
                                    )
                                )
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Brush.radialGradient(listOf(brandColor, Color(0xFF0F172A)))),
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                drawCircle(Color.White.copy(alpha = 0.06f), radius = size.minDimension * 0.42f, center = Offset(size.width * 0.5f, size.height * 0.36f))
                                drawCircle(Color.White.copy(alpha = 0.04f), radius = size.minDimension * 0.62f, center = Offset(size.width * 0.5f, size.height * 0.36f))
                            }
                            Icon(
                                iconForKey(product.iconKey),
                                contentDescription = product.name,
                                tint = Color.White.copy(alpha = 0.92f),
                                modifier = Modifier.size(132.dp).offset(y = (-48).dp)
                            )
                        }
                    }

                    // 2. Top Overlay Badges (Brand/Category + Offer + Reel Index)
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Surface(color = Color.White.copy(alpha = 0.92f), shape = RoundedCornerShape(50)) {
                                Text(
                                    text = "${product.companyName} • ${product.categoryName}",
                                    color = Color(0xFF0F172A),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                )
                            }
                            if (!offerText.isNullOrBlank()) {
                                Surface(color = Color(0xFFF59E0B), shape = RoundedCornerShape(50)) {
                                    Text(
                                        text = "★ $offerText",
                                        color = Color(0xFF0F172A),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                    )
                                }
                            }
                        }

                        Surface(color = Color.Black.copy(alpha = 0.55f), shape = RoundedCornerShape(50)) {
                            Text(
                                text = "${page + 1} / ${filtered.size}",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }

                    // 3. Bottom Frosted Glass Card Overlay with Price & Order Action
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = Color.White.copy(alpha = 0.95f),
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(product.packSize, color = Color(0xFF475569), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Surface(color = Color(0xFFDCFCE7), shape = RoundedCornerShape(50)) {
                                    Text(
                                        "${String.format(Locale.US, "%.0f", marginPct)}% Margin",
                                        color = Color(0xFF166534),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Text(
                                product.name,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 20.sp,
                                color = Color(0xFF0F172A),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(formatRs(product.rate), color = brandColor, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
                                    Text("MRP " + formatRs(product.mrp), color = Color.Gray, fontSize = 12.sp, textDecoration = TextDecoration.LineThrough)
                                }

                                if (qtyInCart == 0) {
                                    Button(
                                        onClick = { vm.addToCart(product.id, 1) },
                                        shape = RoundedCornerShape(16.dp),
                                        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)
                                    ) {
                                        Icon(Icons.Default.AddShoppingCart, null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Add", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    }
                                } else {
                                    Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Surface(
                                            shape = RoundedCornerShape(14.dp),
                                            color = brandColor.copy(alpha = 0.1f),
                                            border = BorderStroke(1.dp, brandColor.copy(alpha = 0.3f))
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 4.dp)) {
                                                IconButton(onClick = { vm.addToCart(product.id, -1) }, modifier = Modifier.size(34.dp)) {
                                                    Icon(Icons.Default.Remove, null, tint = Color(0xFFAE3256))
                                                }
                                                Text("$qtyInCart", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.padding(horizontal = 8.dp))
                                                IconButton(onClick = { vm.addToCart(product.id, 1) }, modifier = Modifier.size(34.dp)) {
                                                    Icon(Icons.Default.Add, null, tint = brandColor)
                                                }
                                            }
                                        }
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Surface(color = brandColor, shape = RoundedCornerShape(8.dp), modifier = Modifier.clickable { vm.addToCart(product.id, 5) }) {
                                                Text("+5", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                                            }
                                            Surface(color = brandColor, shape = RoundedCornerShape(8.dp), modifier = Modifier.clickable { vm.addToCart(product.id, 10) }) {
                                                Text("+10", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CartCheckoutTab(
    vm: DistributorViewModel,
    brandColor: Color,
    onOrderPlaced: () -> Unit,
    onBrowseCatalog: () -> Unit
) {
    val cart by vm.cart.collectAsState()
    val products by vm.repository.products.collectAsState()
    val schemes by vm.repository.schemes.collectAsState()
    val orders by vm.repository.orders.collectAsState()
    val lines = remember(cart, products, schemes) { vm.getCartLineItems() }
    var partyName by remember { mutableStateOf("") }
    var partyMobile by remember { mutableStateOf("") }
    var partyAddress by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Party Order & PDF Checkout", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = brandColor) }
        if (lines.isEmpty()) {
            item {
                ElevatedCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = Color.White)
                ) {
                    Column(Modifier.padding(28.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier.size(68.dp).clip(CircleShape).background(brandColor.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.ShoppingBag, null, tint = brandColor, modifier = Modifier.size(34.dp))
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("No products in cart yet", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                        Spacer(Modifier.height(4.dp))
                        Text("Swipe through the Reels catalog and add items to calculate schemes & generate a Party PDF.", color = Color.Gray, fontSize = 12.sp)
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = onBrowseCatalog, shape = RoundedCornerShape(14.dp)) {
                            Icon(Icons.Default.AutoAwesomeMotion, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Explore Reels Catalog")
                        }
                    }
                }
            }
        } else {
            items(lines) { line ->
                ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(line.itemName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text(formatRs(line.netAmount), fontWeight = FontWeight.ExtraBold, color = brandColor)
                        }
                        Text("MRP ${formatRs(line.mrp)}  |  Rate ${formatRs(line.rate)}  |  Qty: ${line.paidQty} (+${line.freeQty} FREE)", fontSize = 12.sp, color = Color.DarkGray)
                        Text("Offer: ${line.schemeLabel}  •  Savings: ${formatRs(line.discountAmount)}", fontSize = 11.sp, color = Color(0xFF9A5B18), fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            item {
                val recentParties = remember(orders) {
                    orders.filter { it.partyName.isNotBlank() }.distinctBy { it.partyName.trim().lowercase() }.take(6)
                }
                if (recentParties.isNotEmpty()) {
                    Text("Quick-Fill Saved Party (1 Tap)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = brandColor)
                    Spacer(Modifier.height(4.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(recentParties) { past ->
                            AssistChip(
                                onClick = {
                                    partyName = past.partyName
                                    partyMobile = past.partyMobile
                                    partyAddress = past.partyAddress
                                },
                                label = { Text(past.partyName, fontSize = 11.sp) },
                                leadingIcon = { Icon(Icons.Default.Person, null, modifier = Modifier.size(15.dp)) }
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                OutlinedTextField(partyName, { partyName = it }, label = { Text("Party / Shop Name *") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(partyMobile, { partyMobile = it }, label = { Text("10-digit Mobile") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(partyAddress, { partyAddress = it }, label = { Text("Party Address / Route") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(notes, { notes = it }, label = { Text("Order Notes") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
                Spacer(Modifier.height(14.dp))
                val grand = lines.sumOf { it.netAmount }
                val saved = lines.sumOf { it.discountAmount }
                Button(
                    onClick = {
                        val created = vm.placeOrderAndGeneratePdf(partyName, partyMobile, partyAddress, notes)
                        if (created != null) onOrderPlaced()
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.PictureAsPdf, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Place Order & Generate PDF (${formatRs(grand)} | Save ${formatRs(saved)})", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun OrdersPdfTab(
    orders: List<PartyOrder>,
    brandColor: Color,
    onDownloadPdf: (PartyOrder) -> Unit,
    onShareText: (PartyOrder) -> Unit,
    onRepeatOrder: (PartyOrder) -> Unit,
    onUpdateStatus: (String, String) -> Unit
) {
    val fmt = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Party Orders & PDF Invoices", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = brandColor) }
        if (orders.isEmpty()) {
            item { Text("No orders placed yet. Place an order to view & download its PDF invoice.", color = Color.Gray) }
        }
        items(orders, key = { it.id }) { order ->
            ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Surface(color = brandColor.copy(alpha = 0.1f), shape = RoundedCornerShape(8.dp)) {
                                Text(order.id, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = brandColor, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(order.partyName, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                        }
                        Text(formatRs(order.grandTotal), fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, color = brandColor)
                    }
                    Text("${fmt.format(Date(order.createdAt))} • Status: ${order.status}", fontSize = 11.sp, color = Color.Gray)
                    Spacer(Modifier.height(4.dp))
                    Text("${order.items.size} items • ${order.totalFreeUnits} FREE units • Discount ${formatRs(order.totalDiscount)}", fontSize = 12.sp, color = Color(0xFF9A5B18), fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("Accepted", "Packed", "Delivered").forEach { st ->
                            FilterChip(selected = order.status == st, onClick = { onUpdateStatus(order.id, st) }, label = { Text(st, fontSize = 11.sp) })
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { onDownloadPdf(order) }, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Download, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Download & Share PDF Invoice")
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { onShareText(order) }, shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Share, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("WhatsApp Text", fontSize = 12.sp)
                        }
                        OutlinedButton(onClick = { onRepeatOrder(order) }, shape = RoundedCornerShape(12.dp), modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Replay, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Repeat Order", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OwnerStudioTab(
    settings: StoreSettings,
    brandColor: Color,
    products: List<Product>,
    companies: List<Company>,
    categories: List<Category>,
    schemes: List<Scheme>,
    orders: List<PartyOrder>,
    isCloud: Boolean,
    syncStatus: String,
    vm: DistributorViewModel,
    onLockOwner: () -> Unit,
    onAddProduct: () -> Unit,
    onEditProduct: (Product) -> Unit,
    onExport: () -> Unit,
    onImport: () -> Unit
) {
    var ownerSubTab by remember { mutableIntStateOf(0) }
    var distName by remember(settings.distributorName) { mutableStateOf(settings.distributorName) }
    var tagline by remember(settings.tagline) { mutableStateOf(settings.tagline) }
    var announcement by remember(settings.announcement) { mutableStateOf(settings.announcement) }
    var colorHex by remember(settings.primaryColorHex) { mutableStateOf(settings.primaryColorHex) }
    var ownerPinInput by remember(settings.ownerPin) { mutableStateOf(settings.ownerPin) }

    var newCompanyName by remember { mutableStateOf("") }
    var newCategoryName by remember { mutableStateOf("") }

    var productToDelete by remember { mutableStateOf<Product?>(null) }
    var companyToDelete by remember { mutableStateOf<Company?>(null) }
    var categoryToDelete by remember { mutableStateOf<Category?>(null) }

    val schemeMap = remember(schemes) { schemes.associateBy { it.id } }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Owner Studio", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = brandColor)
                    Text("Full control — synced across all devices", fontSize = 12.sp, color = Color.Gray)
                }
                OutlinedButton(onClick = onLockOwner, shape = RoundedCornerShape(12.dp)) {
                    Icon(Icons.Default.Lock, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Lock", fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
            val totalRevenue = orders.sumOf { it.grandTotal }
            val totalFree = orders.sumOf { it.totalFreeUnits }
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF0F172A),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Total Orders", fontSize = 11.sp, color = Color(0xFF94A3B8))
                        Text("${orders.size}", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color.White)
                    }
                    Column {
                        Text("Total Billing", fontSize = 11.sp, color = Color(0xFF94A3B8))
                        Text(formatRs(totalRevenue), fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color(0xFF34D399))
                    }
                    Column {
                        Text("Free Units", fontSize = 11.sp, color = Color(0xFF94A3B8))
                        Text("$totalFree", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color(0xFFFBBF24))
                    }
                }
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Products (${products.size})", "Brands & Cats", "Appearance & PIN", "Sync & Backup").forEachIndexed { idx, label ->
                    item {
                        FilterChip(selected = ownerSubTab == idx, onClick = { ownerSubTab = idx }, label = { Text(label) })
                    }
                }
            }
        }

        when (ownerSubTab) {
            0 -> {
                item {
                    Button(onClick = onAddProduct, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                        Icon(Icons.Default.Add, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Add New Product & Offer")
                    }
                }
                items(products, key = { it.id }) { p ->
                    val offer = p.offerBadge(schemeMap)
                    ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.Bold)
                                Text("${p.companyName} • ${p.packSize} • Rate ${formatRs(p.rate)} / MRP ${formatRs(p.mrp)}", fontSize = 12.sp, color = Color.Gray)
                                if (!offer.isNullOrBlank()) {
                                    Text("Offer: $offer", fontSize = 11.sp, color = Color(0xFF9A5B18), fontWeight = FontWeight.SemiBold)
                                }
                            }
                            IconButton(onClick = { onEditProduct(p) }) { Icon(Icons.Default.Edit, null, tint = Color(0xFF1559A8)) }
                            IconButton(onClick = { vm.repository.upsertProduct(p.copy(available = !p.available)) }) {
                                Icon(if (p.available) Icons.Default.Visibility else Icons.Default.VisibilityOff, null)
                            }
                            IconButton(onClick = { productToDelete = p }) { Icon(Icons.Default.Delete, null, tint = Color(0xFFAE3256)) }
                        }
                    }
                }
            }
            1 -> {
                item {
                    ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Companies / Brands", fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(newCompanyName, { newCompanyName = it }, label = { Text("New Company") }, modifier = Modifier.weight(1f), singleLine = true)
                                Button(onClick = {
                                    if (newCompanyName.isNotBlank()) {
                                        vm.repository.upsertCompany(Company(name = newCompanyName.trim()))
                                        newCompanyName = ""
                                    }
                                }) { Text("Add") }
                            }
                            companies.forEach { c ->
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text(c.name, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                    TextButton(onClick = { vm.repository.upsertCompany(c.copy(hidden = !c.hidden)) }) {
                                        Text(if (c.hidden) "Hidden" else "Visible")
                                    }
                                    IconButton(onClick = { companyToDelete = c }) {
                                        Icon(Icons.Default.Delete, null, tint = Color(0xFFAE3256))
                                    }
                                }
                            }
                        }
                    }
                }
                item {
                    ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Categories", fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(newCategoryName, { newCategoryName = it }, label = { Text("New Category") }, modifier = Modifier.weight(1f), singleLine = true)
                                Button(onClick = {
                                    if (newCategoryName.isNotBlank()) {
                                        vm.repository.upsertCategory(Category(name = newCategoryName.trim()))
                                        newCategoryName = ""
                                    }
                                }) { Text("Add") }
                            }
                            categories.forEach { cat ->
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text(cat.name, modifier = Modifier.weight(1f))
                                    IconButton(onClick = { categoryToDelete = cat }) {
                                        Icon(Icons.Default.Delete, null, tint = Color(0xFFAE3256))
                                    }
                                }
                            }
                        }
                    }
                }
            }
            2 -> {
                item {
                    ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Appearance, Store Info & Synced Owner PIN", fontWeight = FontWeight.Bold)
                            OutlinedTextField(distName, { distName = it }, label = { Text("Distributor / Shop Name") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(tagline, { tagline = it }, label = { Text("Tagline") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(announcement, { announcement = it }, label = { Text("Announcement (leave blank to hide)") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(
                                value = ownerPinInput,
                                onValueChange = { if (it.length <= 8) ownerPinInput = it },
                                label = { Text("Synced Owner PIN (all phones)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text("Brand Colour", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                listOf("#006C67", "#1559A8", "#5B3CC4", "#9A5B18", "#AE3256").forEach { hex ->
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                            .background(Color(android.graphics.Color.parseColor(hex)))
                                            .clickable { colorHex = hex },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (colorHex.equals(hex, true)) {
                                            Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            }
                            Button(
                                onClick = {
                                    vm.repository.updateSettings(
                                        settings.copy(
                                            distributorName = distName.ifBlank { "Shri Sanwariya Distributor" },
                                            tagline = tagline,
                                            announcement = announcement,
                                            primaryColorHex = colorHex,
                                            ownerPin = ownerPinInput.ifBlank { "8107" }
                                        )
                                    )
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Save & Sync Settings") }
                        }
                    }
                }
            }
            3 -> {
                item {
                    ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Cloud Sync Status", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(4.dp))
                            Text(syncStatus, color = if (isCloud) Color(0xFF059669) else Color(0xFFD97706), fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(6.dp))
                            Text("Products: ${products.size}  •  Orders: ${orders.size}", fontSize = 13.sp, color = Color.Gray)
                            Spacer(Modifier.height(10.dp))
                            Button(onClick = { vm.repository.pushAllLocalToCloud() }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.CloudUpload, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Push All Local Data to Cloud Now")
                            }
                        }
                    }
                }
                item {
                    ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Cross-Device Backup & Restore (v4 Fixed)", fontWeight = FontWeight.Bold)
                            Text("Exports a checksum-verified .zip with UTF-8 data and portable product photos that imports cleanly on any phone or PC.", fontSize = 12.sp, color = Color.Gray)
                            Button(onClick = onExport, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.UploadFile, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Export Valid Backup (.zip)")
                            }
                            OutlinedButton(onClick = onImport, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.DownloadForOffline, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Import Backup (.zip or .json)")
                            }
                        }
                    }
                }
            }
        }
    }

    productToDelete?.let { prod ->
        AlertDialog(
            onDismissRequest = { productToDelete = null },
            title = { Text("Delete Product?", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to delete '${prod.name}'? This will remove it from all synced devices.") },
            confirmButton = {
                Button(
                    onClick = { vm.repository.deleteProduct(prod.id); productToDelete = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFAE3256))
                ) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { productToDelete = null }) { Text("Cancel") } }
        )
    }
    companyToDelete?.let { comp ->
        AlertDialog(
            onDismissRequest = { companyToDelete = null },
            title = { Text("Delete Company?", fontWeight = FontWeight.Bold) },
            text = { Text("Delete '${comp.name}'?") },
            confirmButton = {
                Button(
                    onClick = { vm.repository.deleteCompany(comp.id); companyToDelete = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFAE3256))
                ) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { companyToDelete = null }) { Text("Cancel") } }
        )
    }
    categoryToDelete?.let { cat ->
        AlertDialog(
            onDismissRequest = { categoryToDelete = null },
            title = { Text("Delete Category?", fontWeight = FontWeight.Bold) },
            text = { Text("Delete '${cat.name}'?") },
            confirmButton = {
                Button(
                    onClick = { vm.repository.deleteCategory(cat.id); categoryToDelete = null },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFAE3256))
                ) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { categoryToDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun iconForKey(key: String) = when (key) {
    "cosmetic" -> Icons.Default.FaceRetouchingNatural
    "bottle" -> Icons.Default.LocalDrink
    "soap" -> Icons.Default.CleanHands
    "baby" -> Icons.Default.ChildCare
    "home" -> Icons.Default.Home
    else -> Icons.Default.Inventory2
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductEditorDialog(
    existing: Product?,
    companies: List<Company>,
    categories: List<Category>,
    vm: DistributorViewModel,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var packSize by remember { mutableStateOf(existing?.packSize ?: "1 kg") }
    var mrp by remember { mutableStateOf(existing?.mrp?.toString() ?: "") }
    var rate by remember { mutableStateOf(existing?.rate?.toString() ?: "") }
    var selectedCompany by remember { mutableStateOf(companies.find { it.id == existing?.companyId } ?: companies.firstOrNull()) }
    var selectedCategory by remember { mutableStateOf(categories.find { it.id == existing?.categoryId } ?: categories.firstOrNull()) }
    var selectedIconKey by remember { mutableStateOf(existing?.iconKey ?: "box") }
    var pickedPhotoUri by remember { mutableStateOf<Uri?>(null) }

    var offerType by remember { mutableStateOf(existing?.offerType ?: "NONE") }
    var offerMinPaid by remember { mutableStateOf((existing?.offerMinPaid ?: 10).toString()) }
    var offerFreeUnits by remember { mutableStateOf((existing?.offerFreeUnits ?: 2).toString()) }
    var offerValue by remember { mutableStateOf(if ((existing?.offerValue ?: 0.0) > 0) existing!!.offerValue.toString() else "10") }
    var offerCustomText by remember { mutableStateOf(existing?.offerCustomText ?: "") }

    var companyExpanded by remember { mutableStateOf(false) }
    var categoryExpanded by remember { mutableStateOf(false) }
    var offerExpanded by remember { mutableStateOf(false) }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> pickedPhotoUri = uri }

    val iconOptions = listOf(
        "box" to "General",
        "cosmetic" to "Cosmetic",
        "bottle" to "Liquid",
        "soap" to "Hygiene",
        "baby" to "Baby",
        "home" to "Home"
    )
    val offerOptions = listOf(
        "NONE" to "No Offer / Standard Rate",
        "FREE_UNITS" to "Free Units (Buy X + Y FREE)",
        "PERCENT_OFF_MRP" to "% Off MRP",
        "FLAT_PER_UNIT" to "Flat ₹ Off / Unit"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Add New Product" else "Edit Product", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(name, { name = it }, label = { Text("Product Name *") }, singleLine = true, modifier = Modifier.fillMaxWidth())

                ExposedDropdownMenuBox(expanded = companyExpanded, onExpandedChange = { companyExpanded = !companyExpanded }) {
                    OutlinedTextField(
                        value = selectedCompany?.name ?: "Select Company",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Company / Brand") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = companyExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = companyExpanded, onDismissRequest = { companyExpanded = false }) {
                        companies.forEach { c ->
                            DropdownMenuItem(text = { Text(c.name) }, onClick = { selectedCompany = c; companyExpanded = false })
                        }
                    }
                }

                ExposedDropdownMenuBox(expanded = categoryExpanded, onExpandedChange = { categoryExpanded = !categoryExpanded }) {
                    OutlinedTextField(
                        value = selectedCategory?.name ?: "Select Category",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Category (General / Cosmetic / etc.)") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = categoryExpanded, onDismissRequest = { categoryExpanded = false }) {
                        categories.forEach { cat ->
                            DropdownMenuItem(text = { Text(cat.name) }, onClick = { selectedCategory = cat; categoryExpanded = false })
                        }
                    }
                }

                OutlinedTextField(packSize, { packSize = it }, label = { Text("Pack Size (e.g. 250 ml, 1 kg)") }, singleLine = true, modifier = Modifier.fillMaxWidth())

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(mrp, { mrp = it }, label = { Text("MRP ₹ *") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(rate, { rate = it }, label = { Text("Rate ₹ *") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                val mrpNum = mrp.toDoubleOrNull() ?: 0.0
                val rateNum = rate.toDoubleOrNull() ?: 0.0
                if (mrpNum > 0 && rateNum > 0) {
                    val marginPct = ((mrpNum - rateNum) / mrpNum) * 100.0
                    Text(
                        text = "Margin: ${String.format(Locale.US, "%.1f", marginPct)}% (Profit ${formatRs(mrpNum - rateNum)} / unit on MRP)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (marginPct >= 0) Color(0xFF059669) else Color(0xFFAE3256)
                    )
                }

                ExposedDropdownMenuBox(expanded = offerExpanded, onExpandedChange = { offerExpanded = !offerExpanded }) {
                    OutlinedTextField(
                        value = offerOptions.find { it.first == offerType }?.second ?: "No Offer",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Offer / Scheme for this Product") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = offerExpanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = offerExpanded, onDismissRequest = { offerExpanded = false }) {
                        offerOptions.forEach { (key, label) ->
                            DropdownMenuItem(text = { Text(label) }, onClick = { offerType = key; offerExpanded = false })
                        }
                    }
                }

                if (offerType == "FREE_UNITS") {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(offerMinPaid, { offerMinPaid = it }, label = { Text("Buy Qty") }, modifier = Modifier.weight(1f), singleLine = true)
                        OutlinedTextField(offerFreeUnits, { offerFreeUnits = it }, label = { Text("Free Qty") }, modifier = Modifier.weight(1f), singleLine = true)
                    }
                } else if (offerType == "PERCENT_OFF_MRP" || offerType == "FLAT_PER_UNIT") {
                    OutlinedTextField(
                        value = offerValue,
                        onValueChange = { offerValue = it },
                        label = { Text(if (offerType == "PERCENT_OFF_MRP") "Discount % on MRP" else "Flat ₹ Off per Unit") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (offerType != "NONE") {
                    OutlinedTextField(
                        value = offerCustomText,
                        onValueChange = { offerCustomText = it },
                        label = { Text("Custom Offer Label (optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Text("Product Icon (or upload photo below)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(iconOptions) { (key, label) ->
                        FilterChip(
                            selected = selectedIconKey == key,
                            onClick = { selectedIconKey = key },
                            leadingIcon = { Icon(iconForKey(key), null, modifier = Modifier.size(16.dp)) },
                            label = { Text(label, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedButton(onClick = { photoPicker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Image, null)
                    Spacer(Modifier.width(6.dp))
                    Text(if (pickedPhotoUri != null) "New Photo Selected ✓" else "Pick / Change Product Photo")
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val mrpVal = mrp.toDoubleOrNull() ?: 0.0
                val rateVal = rate.toDoubleOrNull() ?: mrpVal
                if (name.isNotBlank() && mrpVal > 0) {
                    val prodId = existing?.id ?: "prod_${System.currentTimeMillis()}"
                    val savedImg = pickedPhotoUri?.let { vm.backupManager.saveProductImageFromUri(prodId, it) } ?: existing?.imageRelativePath
                    val comp = selectedCompany ?: Company("comp_gen", "General")
                    val cat = selectedCategory ?: Category("cat_gen", "General")
                    vm.repository.upsertProduct(
                        Product(
                            id = prodId,
                            name = name.trim(),
                            companyId = comp.id,
                            companyName = comp.name,
                            categoryId = cat.id,
                            categoryName = cat.name,
                            packSize = packSize.ifBlank { "1 unit" },
                            mrp = mrpVal,
                            rate = rateVal,
                            offerType = offerType,
                            offerMinPaid = offerMinPaid.toIntOrNull() ?: 10,
                            offerFreeUnits = offerFreeUnits.toIntOrNull() ?: 1,
                            offerValue = offerValue.toDoubleOrNull() ?: 0.0,
                            offerCustomText = offerCustomText.trim(),
                            imageRelativePath = savedImg,
                            iconKey = selectedIconKey,
                            available = existing?.available ?: true
                        )
                    )
                    onDismiss()
                }
            }) { Text("Save & Sync") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
